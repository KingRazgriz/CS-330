///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include <iostream>

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

namespace {
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

SceneManager::SceneManager(ShaderManager* pShaderManager) {
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    // Initialize lighting defaults
    m_directionalLightDirection = glm::vec3(-0.5f, -1.0f, -0.3f);
    m_directionalLightColor = glm::vec3(1.0f, 1.0f, 0.9f);
    m_pointLightPosition = glm::vec3(0.0f, 5.0f, 0.0f);
    m_pointLightColor = glm::vec3(0.3f, 0.3f, 0.4f);
}

SceneManager::~SceneManager() {
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag) {
    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (image) {
        std::cout << "Successfully loaded image:" << filename << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cout << "Could not load image:" << filename << std::endl;
    return false;
}

void SceneManager::BindGLTextures() {
    for (int i = 0; i < m_loadedTextures; i++) {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

void SceneManager::DestroyGLTextures() {
    for (int i = 0; i < m_loadedTextures; i++) {
        glGenTextures(1, &m_textureIDs[i].ID);
    }
}

int SceneManager::FindTextureID(std::string tag) {
    for (int i = 0; i < m_loadedTextures; i++) {
        if (m_textureIDs[i].tag == tag)
            return m_textureIDs[i].ID;
    }
    return -1;
}

int SceneManager::FindTextureSlot(std::string tag) {
    for (int i = 0; i < m_loadedTextures; i++) {
        if (m_textureIDs[i].tag == tag)
            return i;
    }
    return -1;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material) {
    for (auto& mat : m_objectMaterials) {
        if (mat.tag == tag) {
            material = mat;
            return true;
        }
    }
    return false;
}

void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ) {

    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, positionXYZ);
    model = glm::rotate(model, glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    model = glm::rotate(model, glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    model = glm::rotate(model, glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    model = glm::scale(model, scaleXYZ);

    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, model);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a) {
    if (m_pShaderManager) {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
    }
}

void SceneManager::SetShaderTexture(std::string textureTag) {
    if (m_pShaderManager) {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        int textureSlot = FindTextureSlot(textureTag);
        if (textureSlot >= 0)
            m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
    }
}

void SceneManager::SetTextureUVScale(float u, float v) {
    if (m_pShaderManager)
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

void SceneManager::SetShaderMaterial(std::string materialTag) {
    OBJECT_MATERIAL material;
    if (FindMaterial(materialTag, material)) {
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
}

void SceneManager::SetupSceneLights() {
    if (!m_pShaderManager) return;

    // Directional light (sun)
    m_pShaderManager->setVec3Value("directionalLight.direction", m_directionalLightDirection);
    m_pShaderManager->setVec3Value("directionalLight.ambient", m_directionalLightColor * 0.2f);
    m_pShaderManager->setVec3Value("directionalLight.diffuse", m_directionalLightColor * 0.8f);
    m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(1.0f));

    // Point light (fill light)
    m_pShaderManager->setVec3Value("pointLight.position", m_pointLightPosition);
    m_pShaderManager->setVec3Value("pointLight.ambient", m_pointLightColor * 0.1f);
    m_pShaderManager->setVec3Value("pointLight.diffuse", m_pointLightColor * 0.5f);
    m_pShaderManager->setVec3Value("pointLight.specular", m_pointLightColor * 0.5f);
    m_pShaderManager->setFloatValue("pointLight.constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLight.linear", 0.09f);
    m_pShaderManager->setFloatValue("pointLight.quadratic", 0.032f);

    m_pShaderManager->setIntValue(g_UseLightingName, true);
}

void SceneManager::PrepareScene() {
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadTorusMesh();

    // Load textures
    CreateGLTexture("../../Utilities/textures/pavers.jpg", "floor");
    CreateGLTexture("../../Utilities/textures/gold-seamless-texture.jpg", "can_body");
    CreateGLTexture("../../Utilities/textures/circular-brushed-gold-texture.jpg", "can_top");
    CreateGLTexture("../../Utilities/textures/stainless.jpg", "bowl_body");
    CreateGLTexture("../../Utilities/textures/stainless_end.jpg", "bowl_rim");
    CreateGLTexture("../../Utilities/textures/cheese_wheel.jpg", "bottle_body");
    CreateGLTexture("../../Utilities/textures/knife_handle.jpg", "bottle_cap");
    CreateGLTexture("../../Utilities/textures/cheddar.jpg", "bottle_label");

    // Define materials
    OBJECT_MATERIAL floorMaterial;
    floorMaterial.tag = "floor";
    floorMaterial.ambientColor = glm::vec3(0.2f);
    floorMaterial.ambientStrength = 0.5f;
    floorMaterial.diffuseColor = glm::vec3(0.8f);
    floorMaterial.specularColor = glm::vec3(0.1f);
    floorMaterial.shininess = 32.0f;
    m_objectMaterials.push_back(floorMaterial);

    OBJECT_MATERIAL metalMaterial;
    metalMaterial.tag = "metal";
    metalMaterial.ambientColor = glm::vec3(0.25f);
    metalMaterial.ambientStrength = 0.3f;
    metalMaterial.diffuseColor = glm::vec3(0.6f);
    metalMaterial.specularColor = glm::vec3(0.8f);
    metalMaterial.shininess = 128.0f;
    m_objectMaterials.push_back(metalMaterial);

    OBJECT_MATERIAL glassMaterial;
    glassMaterial.tag = "glass";
    glassMaterial.ambientColor = glm::vec3(0.1f);
    glassMaterial.ambientStrength = 0.2f;
    glassMaterial.diffuseColor = glm::vec3(0.4f);
    glassMaterial.specularColor = glm::vec3(0.9f);
    glassMaterial.shininess = 256.0f;
    m_objectMaterials.push_back(glassMaterial);

    BindGLTextures();
}

void SceneManager::RenderScene() {
    SetupSceneLights();

    auto drawObject = [this](const glm::vec3& scale, const glm::vec3& pos,
        const std::string& texture, const std::string& materialTag,
        float alpha = 1.0f, const std::string& meshType = "box") {
            SetTransformations(scale, 0, 0, 0, pos);
            SetShaderTexture(texture);
            SetShaderMaterial(materialTag);
            SetShaderColor(1, 1, 1, alpha);

            if (meshType == "sphere") m_basicMeshes->DrawSphereMesh();
            else if (meshType == "cylinder") m_basicMeshes->DrawCylinderMesh();
            else if (meshType == "tapered") m_basicMeshes->DrawTaperedCylinderMesh();
            else if (meshType == "plane") m_basicMeshes->DrawPlaneMesh();
            else m_basicMeshes->DrawBoxMesh();
        };

    // Draw scene
    drawObject({ 20,1,10 }, { 0,0,0 }, "floor", "floor", 1.0f, "plane");

    // Peanut Can
    drawObject({ 1,2,1 }, { -4,1,6 }, "can_body", "metal", 1.0f, "cylinder");
    drawObject({ 1.05f,0.1f,1.05f }, { -4,3.1f,6 }, "can_top", "metal", 1.0f, "cylinder");

    // Mixing Bowl
    const float bowlWidth = 2.5f, bowlHeight = 1.25f;
    drawObject({ bowlWidth, bowlHeight, bowlWidth }, { 4,bowlHeight / 2,-5 }, "bowl_body", "metal", 1.0f, "sphere");
    drawObject({ bowlWidth + 0.15f, 0.08f, bowlWidth + 0.15f }, { 4,bowlHeight - 0.04f,-5 }, "bowl_rim", "metal", 1.0f, "cylinder");
    drawObject({ bowlWidth + 0.15f, 0.3f, bowlWidth + 0.15f }, { 4,bowlHeight + 0.15f,-5 }, "bowl_rim", "metal", 1.0f, "sphere");

    // Syrup Bottle
    const float bottleY = bowlHeight + 1.0f;
    drawObject({ 0.3f,2.0f,0.3f }, { 4,bottleY,-5 }, "bottle_body", "glass", 0.8f, "tapered");
    drawObject({ 0.18f,0.5f,0.18f }, { 4,bottleY + 1.25f,-5 }, "bottle_body", "glass", 0.9f, "cylinder");
    drawObject({ 0.21f,0.2f,0.21f }, { 4,bottleY + 1.5f,-5 }, "bottle_cap", "metal", 1.0f, "cylinder");
    drawObject({ 0.54f,1.2f,0.01f }, { 4,bottleY,-5.27f }, "bottle_label", "floor", 1.0f, "box");
}

