///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

ViewManager* ViewManager::s_instance = nullptr;

ViewManager::ViewManager(ShaderManager* pShaderManager) :
    m_pShaderManager(pShaderManager),
    m_pWindow(nullptr),
    m_cameraPos(0.0f, 1.0f, 5.0f),
    m_cameraFront(0.0f, 0.0f, -1.0f),
    m_cameraUp(0.0f, 1.0f, 0.0f),
    m_yaw(-90.0f),
    m_pitch(0.0f),
    m_cameraSpeed(5.0f),
    m_mouseSensitivity(0.1f),
    m_zoom(45.0f),
    m_lastFrame(0.0f)
{
    s_instance = this;
}

ViewManager::~ViewManager() {
    glDeleteVertexArrays(1, &m_planeVAO);
    glDeleteBuffers(1, &m_planeVBO);
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle) {
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;

    m_pWindow = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
    if (!m_pWindow) return nullptr;

    glfwMakeContextCurrent(m_pWindow);
    glfwSetCursorPosCallback(m_pWindow, Mouse_Position_Callback);
    glfwSetScrollCallback(m_pWindow, Mouse_Scroll_Callback);
    glfwSetInputMode(m_pWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    return m_pWindow;
}

void ViewManager::Create3DPlane() {
    float planeVertices[] = {
        // positions          // normals         // texture coords
        -10.0f, 0.0f, -10.0f, 0.0f, 1.0f, 0.0f, 0.0f, 10.0f,
         10.0f, 0.0f, -10.0f, 0.0f, 1.0f, 0.0f, 10.0f, 10.0f,
         10.0f, 0.0f,  10.0f, 0.0f, 1.0f, 0.0f, 10.0f, 0.0f,
         10.0f, 0.0f,  10.0f, 0.0f, 1.0f, 0.0f, 10.0f, 0.0f,
        -10.0f, 0.0f,  10.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
        -10.0f, 0.0f, -10.0f, 0.0f, 1.0f, 0.0f, 0.0f, 10.0f
    };

    glGenVertexArrays(1, &m_planeVAO);
    glGenBuffers(1, &m_planeVBO);

    glBindVertexArray(m_planeVAO);
    glBindBuffer(GL_ARRAY_BUFFER, m_planeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

    // Position attribute
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    // Normal attribute
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    // Texture coordinate attribute
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));

    glBindVertexArray(0);
}

void ViewManager::Render3DPlane() {
    if (m_pShaderManager && m_planeVAO) {
        m_pShaderManager->useShaderProgram("BasicShader");

        glm::mat4 model = glm::mat4(1.0f);
        m_pShaderManager->setMat4Value("model", model);

        glBindVertexArray(m_planeVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glBindVertexArray(0);
    }
}

void ViewManager::ProcessKeyboardEvents() {
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_pWindow, true);

    float velocity = m_cameraSpeed * m_deltaTime;

    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        m_cameraPos += velocity * m_cameraFront;
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        m_cameraPos -= velocity * m_cameraFront;
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        m_cameraPos -= glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * velocity;
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        m_cameraPos += glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * velocity;
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        m_cameraPos += velocity * m_cameraUp;
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        m_cameraPos -= velocity * m_cameraUp;
}

void ViewManager::ProcessMouseMovement(float xoffset, float yoffset) {
    xoffset *= m_mouseSensitivity;
    yoffset *= m_mouseSensitivity;

    m_yaw += xoffset;
    m_pitch += yoffset;

    if (m_pitch > 89.0f) m_pitch = 89.0f;
    if (m_pitch < -89.0f) m_pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(m_yaw)) * cos(glm::radians(m_pitch));
    front.y = sin(glm::radians(m_pitch));
    front.z = sin(glm::radians(m_yaw)) * cos(glm::radians(m_pitch));
    m_cameraFront = glm::normalize(front);
}

void ViewManager::ProcessMouseScroll(float yoffset) {
    m_zoom -= yoffset;
    if (m_zoom < 1.0f) m_zoom = 1.0f;
    if (m_zoom > 90.0f) m_zoom = 90.0f;
}

void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xpos, double ypos) {
    static float lastX = 400, lastY = 300;
    static bool firstMouse = true;

    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    if (s_instance) {
        s_instance->ProcessMouseMovement(xoffset, yoffset);
    }
}

void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset) {
    if (s_instance) {
        s_instance->ProcessMouseScroll(yoffset);
    }
}

void ViewManager::PrepareSceneView() {
    float currentFrame = glfwGetTime();
    m_deltaTime = currentFrame - m_lastFrame;
    m_lastFrame = currentFrame;

    ProcessKeyboardEvents();

    glm::mat4 view = glm::lookAt(m_cameraPos, m_cameraPos + m_cameraFront, m_cameraUp);
    glm::mat4 projection = glm::perspective(glm::radians(m_zoom), 1000.0f / 800.0f, 0.1f, 100.0f);

    m_pShaderManager->setMat4Value("view", view);
    m_pShaderManager->setMat4Value("projection", projection);
    m_pShaderManager->setVec3Value("viewPosition", m_cameraPos);
}