///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "ShaderManager.h"

class ViewManager {
public:
    enum CameraMovement {
        FORWARD, BACKWARD, LEFT, RIGHT, UP, DOWN
    };

    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    GLFWwindow* CreateDisplayWindow(const char* windowTitle);
    void PrepareSceneView();
    void Create3DPlane();
    void Render3DPlane();

private:
    // Camera variables
    glm::vec3 m_cameraPos;
    glm::vec3 m_cameraFront;
    glm::vec3 m_cameraUp;
    float m_yaw;
    float m_pitch;
    float m_cameraSpeed;
    float m_mouseSensitivity;
    float m_zoom;

    // Plane variables
    unsigned int m_planeVAO;
    unsigned int m_planeVBO;

    // Other members
    ShaderManager* m_pShaderManager;
    GLFWwindow* m_pWindow;
    float m_lastFrame;
    float m_deltaTime;

    // Input handling
    void ProcessKeyboardEvents();
    void ProcessMouseMovement(float xoffset, float yoffset);
    void ProcessMouseScroll(float yoffset);
    static void Mouse_Position_Callback(GLFWwindow* window, double xpos, double ypos);
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset);
    static ViewManager* s_instance; // For static callbacks to access instance
};