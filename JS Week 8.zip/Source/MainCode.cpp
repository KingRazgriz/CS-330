#include <GLFW/glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <vector>
#include <time.h>

using namespace std;

const float DEG2RAD = 3.14159f / 180.0f;

void processInput(GLFWwindow* window);

// Enumerations for brick types and states
enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

// Class for the paddle
class Paddle {
public:
    float x, y, width, height;
    float red, green, blue;

    Paddle(float xx, float yy, float ww, float hh, float rr, float gg, float bb) {
        x = xx;
        y = yy;
        width = ww;
        height = hh;
        red = rr;
        green = gg;
        blue = bb;
    }

    void drawPaddle() {
        glColor3d(red, green, blue);
        glBegin(GL_POLYGON);

        glVertex2d(x + width / 2, y + height / 2);
        glVertex2d(x + width / 2, y - height / 2);
        glVertex2d(x - width / 2, y - height / 2);
        glVertex2d(x - width / 2, y + height / 2);

        glEnd();
    }

    void move(float dx) {
        x += dx;
        if (x - width / 2 < -1) x = -1 + width / 2;
        if (x + width / 2 > 1) x = 1 - width / 2;
    }
};

// Class for bricks - modified for red/blue color scheme
class Brick {
public:
    float red, green, blue;
    float x, y, width, height;
    BRICKTYPE brick_type;
    ONOFF onoff;
    int hitPoints;

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float hh, float rr, float gg, float bb, int hp) {
        brick_type = bt;
        x = xx;
        y = yy;
        width = ww;
        height = hh;
        red = rr;
        green = gg;
        blue = bb;
        onoff = ON;
        hitPoints = hp;
    }

    void drawBrick() {
        if (onoff == ON) {
            glColor3d(red, green, blue);
            glBegin(GL_POLYGON);

            glVertex2d(x + width / 2, y + height / 2);
            glVertex2d(x + width / 2, y - height / 2);
            glVertex2d(x - width / 2, y - height / 2);
            glVertex2d(x - width / 2, y + height / 2);

            glEnd();
        }
    }

    void updateColor() {
        if (brick_type == DESTRUCTABLE) {
            // Blue bricks get darker as they take damage
            switch (hitPoints) {
            case 2:
                red = 0.0f; green = 0.0f; blue = 0.6f; // Medium blue
                break;
            case 1:
                red = 0.0f; green = 0.0f; blue = 0.3f; // Dark blue
                break;
            default:
                break;
            }
        }
    }
};

// Class for circles - modified for white color only
class Circle {
public:
    float red, green, blue;
    float radius;
    float x;
    float y;
    float speedX;
    float speedY;
    bool active;

    Circle(float xx, float yy, float rad, float sX, float sY) { // Removed color parameters
        x = xx;
        y = yy;
        radius = rad;
        speedX = sX;
        speedY = sY;
        red = 1.0f;   // Always white
        green = 1.0f;  // Always white
        blue = 1.0f;   // Always white
        active = true;
    }

    void CheckCollision(Brick* brk) {
        if (brk->onoff == ON) {
            if (x + radius > brk->x - brk->width / 2 &&
                x - radius < brk->x + brk->width / 2 &&
                y + radius > brk->y - brk->height / 2 &&
                y - radius < brk->y + brk->height / 2) {

                if (brk->brick_type == REFLECTIVE) {
                    speedY = -speedY;
                }
                else if (brk->brick_type == DESTRUCTABLE) {
                    brk->hitPoints--;
                    brk->updateColor();
                    if (brk->hitPoints <= 0) {
                        brk->onoff = OFF;
                    }
                    speedY = -speedY;
                }
            }
        }
    }

    void CheckCollision(Paddle* paddle) {
        if (x + radius > paddle->x - paddle->width / 2 &&
            x - radius < paddle->x + paddle->width / 2 &&
            y - radius < paddle->y + paddle->height / 2 &&
            y + radius > paddle->y - paddle->height / 2) {
            speedY = fabs(speedY);
            float hitPos = (x - paddle->x) / (paddle->width / 2);
            speedX = hitPos * 0.02f;
            y = paddle->y + paddle->height / 2 + radius;
        }
    }

    void CheckWallCollision() {
        if (x - radius < -1) {
            x = -1 + radius;
            speedX = -speedX;
        }
        if (x + radius > 1) {
            x = 1 - radius;
            speedX = -speedX;
        }
        if (y + radius > 1) {
            y = 1 - radius;
            speedY = -speedY;
        }
        if (y - radius < -1) {
            active = false;
        }
    }

    void CheckCollision(std::vector<Circle>& circles) {
        for (auto& other : circles) {
            if (&other != this && other.active) {
                float dx = x - other.x;
                float dy = y - other.y;
                float distance = sqrt(dx * dx + dy * dy);
                if (distance < radius + other.radius) {
                    active = false;
                    other.active = false;
                    // New merged circle is also white
                    Circle newCircle((x + other.x) / 2, (y + other.y) / 2,
                        radius + other.radius, (speedX + other.speedX) / 2,
                        (speedY + other.speedY) / 2);
                    circles.push_back(newCircle);
                    break;
                }
            }
        }
    }

    void MoveOneStep() {
        x += speedX;
        y += speedY;
    }

    void DrawCircle() {
        if (active) {
            glColor3f(red, green, blue);
            glBegin(GL_POLYGON);
            for (int i = 0; i < 360; i++) {
                float degInRad = i * DEG2RAD;
                glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
            }
            glEnd();
        }
    }
};

std::vector<Circle> world;
std::vector<Brick> bricks;
Paddle paddle(0.0f, -0.9f, 0.4f, 0.05f, 0.7f, 0.7f, 0.7f); // Gray paddle
float paddleSpeed = 0.05f;

int main(void) {
    srand(static_cast<unsigned int>(time(NULL)));

    if (!glfwInit()) {
        exit(EXIT_FAILURE);
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(640, 640, "Breakout Game", NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // Create brick grid with red/blue color scheme
    float startX = -0.8f;
    float startY = 0.6f;
    float brickWidth = 0.2f;
    float brickHeight = 0.1f;
    int rows = 3;
    int cols = 8;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            float x = startX + j * (brickWidth + 0.02f);
            float y = startY - i * (brickHeight + 0.02f);
            BRICKTYPE type = (i + j) % 2 == 0 ? DESTRUCTABLE : REFLECTIVE;
            int hitPoints = type == DESTRUCTABLE ? 3 : 0;
            // Red for reflective, blue for destructible
            float r = type == REFLECTIVE ? 1.0f : 0.0f;
            float g = 0.0f;
            float b = type == DESTRUCTABLE ? 1.0f : 0.0f;
            bricks.emplace_back(type, x, y, brickWidth, brickHeight, r, g, b, hitPoints);
        }
    }

    while (!glfwWindowShouldClose(window)) {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float)height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        for (auto& circle : world) {
            if (circle.active) {
                circle.MoveOneStep();
                circle.CheckWallCollision();
                circle.CheckCollision(&paddle);

                for (auto& brick : bricks) {
                    circle.CheckCollision(&brick);
                }

                circle.CheckCollision(world);
            }
        }

        world.erase(remove_if(world.begin(), world.end(),
            [](Circle& c) { return !c.active; }), world.end());

        for (auto& circle : world) {
            circle.DrawCircle();
        }

        for (auto& brick : bricks) {
            brick.drawBrick();
        }

        paddle.drawPaddle();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

void processInput(GLFWwindow* window) {
    static bool spacePressed = false;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        paddle.move(-paddleSpeed);
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        paddle.move(paddleSpeed);

    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        if (!spacePressed) {
            spacePressed = true;
            // Create white ball only
            float speedX = ((rand() % 200) - 100) / 5000.0f;
            float speedY = 0.02f;
            Circle newCircle(0.0f, -0.85f, 0.03f, speedX, speedY);
            world.push_back(newCircle);
        }
    }
    else {
        spacePressed = false;
    }
}